// JS separado (dentro do mesmo arquivo para facilidade). Se você preferir em arquivo .js, corte este bloco.
(function () {
    const modal = document.getElementById('modal');
    const close = document.getElementById('close-modal');
    const mPoster = document.getElementById('m-poster');
    const mTitle = document.getElementById('modal-title');
    const mDesc = document.getElementById('modal-desc');

    function openModal(title, desc, img) {
        mPoster.style.backgroundImage = `url('${img}')`;
        mTitle.textContent = title;
        mDesc.textContent = desc;
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
    function closeModal() {
        modal.style.display = 'none';
        document.body.style.overflow = '';
    }


    document.getElementById('open-feature').addEventListener('click', function () {
        openModal('O Grande Mistério — Releitura', 'Sinopse detalhada do destaque. Nesta releitura imaginária temos personagens complexos, muitos mistérios e uma trilha sonora marcante.', document.querySelector('.featured').style.backgroundImage.slice(5, -2));
    });


    document.querySelectorAll('.card .more').forEach(btn => {
        btn.addEventListener('click', function (e) {
            const card = e.target.closest('.card');
            const title = card.getAttribute('data-title') || 'Título';
            const desc = card.getAttribute('data-desc') || 'Descrição disponível em breve.';
            const img = card.getAttribute('data-img') || card.querySelector('.poster').style.backgroundImage.slice(5, -2);
            openModal(title, desc, img);
        });
    });

    close.addEventListener('click', closeModal);
    modal.addEventListener('click', function (e) { if (e.target === modal) closeModal(); });


    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });

})();